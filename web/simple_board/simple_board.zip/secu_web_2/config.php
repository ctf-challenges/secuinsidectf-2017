<?php #config.php
	$db_con = mysqli_connect('localhost', '###blind####', '###blind####');
	mysqli_select_db($db_con, 'simple_board');
?>